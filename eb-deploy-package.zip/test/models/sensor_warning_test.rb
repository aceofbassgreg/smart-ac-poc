require 'test_helper'

class SensorWarningTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
