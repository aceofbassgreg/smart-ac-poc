require 'test_helper'

class SensorReadingTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
