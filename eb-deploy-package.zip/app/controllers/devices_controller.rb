class DevicesController < ApplicationController
  before_action :authenticate_user!

  def create
  end

  def show
  end

  def index
  end
end
