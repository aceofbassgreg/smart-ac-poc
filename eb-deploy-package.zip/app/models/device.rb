class Device < ApplicationRecord
  has_many :sensor_readings
end
