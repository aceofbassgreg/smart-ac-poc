class SensorReading < ApplicationRecord
  belongs_to :device
end
