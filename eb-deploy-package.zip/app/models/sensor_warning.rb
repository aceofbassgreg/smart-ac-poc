class SensorWarning < ApplicationRecord
  belongs_to :device
end
